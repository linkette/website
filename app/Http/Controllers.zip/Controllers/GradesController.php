<?php

namespace App\Http\Controllers;

use App\Models\grades;
use Illuminate\Http\Request;

class GradesController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $grades = grades::all();
        return view('grades.index', compact('grades'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('grades.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validateData = $request->validate([
            'student_id' => 'required|exists:students.id',
            'subject_id' =>'required|exists:subject.id',
            'grade' =>'required|numeric|min:0|max:100',
            'date' =>'required|date',
        ]);
        //nueva asignacion creada
        grades::create($validateData);
        return redirect()->route('grades.index')->with('success', 'Calificacion Creada Correctamente');
    }

    /**
     * Display the specified resource.
     */
    public function show(grades $grades)
    {
        $grades = Grade::fin($id);
        return view('grades.show', compact('grades'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(grades $grades)
    {
        $grades = Grade::find($id);
        return view('grades.edit', compact('grades'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, grades $grades)
    {
        $validateData = $request->validate([
          'student_id' =>'required|exists:students.id',
          'subject_id' =>'required|exists:subject.id',
            'grade' =>'required|numeric|min:0|max:100',
            'date' =>'required|date',
        ]);
        $grades = Grade::find($id);
        $grades->update($validateData);
        return redirect()->route('grades.index')->with('success', 'Calificacion Editada Correctamente');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(grades $grades)
    {
        $grades->delete();
        return redirect()->route('grades.index')->with('success', 'Calificacion Eliminada Correctamente');
    }
}
