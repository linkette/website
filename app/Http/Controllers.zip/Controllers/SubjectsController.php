<?php

namespace App\Http\Controllers;

use App\Models\subjects;
use Illuminate\Http\Request;

class SubjectsController extends Controller
{   
   
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $subjects = subjects::all();
        return view('subjects.index', compact('subjects'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('subjects.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //validar el furmulario
        $validateData = $request->validate([
            'code' =>'required|string|max:255|unique:subjects',
            'name' =>'required|string|max:255',
            
        ]);
        //guardar el registro
        $subjects = Subjetct::create($validateData);
        return redirect()->route('subjects.index')->with(' creado ', ' Asignatura creada correctamente ');
    }

    /**
     * Display the specified resource.
     */
    public function show(subjects $subjects)
    {
        $subjects = Subject::find($id);
        return view('subjects.show', compact('subjects'));

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(subjects $subjects)
    {
        $subjects = Subject::find($id);
        return view('subjects.edit', compact('subjects'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, subjects $subjects)
    {
        //validar el furmulario
        $validateData = $request->validate([
            'code' =>'required|string|max:255|uniqued:subjects.code,' . $id,
            'name' =>'required|string|max:255',
            
        ]);
        //guardar el registro
        $subjects = Subject::find($id)->update($validateData);
        return redirect()->route('subjects.index')->with(' actualizado ','Asignatura actualizada correctamente ');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(subjects $subjects)
    {
        $subjects = Subject::find($id)->delete();
        return redirect()->route('subjects.index')->with(' eliminado ','Asignatura eliminada correctamente ');
    }
}
