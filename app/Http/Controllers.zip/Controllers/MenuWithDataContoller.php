<?php

namespace App\Http\Controllers;
use App\Models\Student;
use App\Models\Subject;

class MenuWithDataController extends Controller
{
    public function index()
    {
        $students = Student::all();
        $subjects = Subject::all();

        return view('menu-con-datos.index', compact('students', 'subjects'));
    }
}
